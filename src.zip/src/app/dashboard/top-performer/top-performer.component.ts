import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-top-performer',
  templateUrl: './top-performer.component.html',
  styleUrls: ['./top-performer.component.scss']
})
export class TopPerformerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
