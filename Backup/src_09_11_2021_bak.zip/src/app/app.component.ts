import { Component,HostListener, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { LoginService } from './service/login/login.service';
import { AuthService } from './_helpers/PasswordValidator/auth/auth.timerLogout';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'unfyd-link-app';
  currentUser: any ;
  isHidden : boolean = true;
  activetimer : boolean = false;
  timerSubscription: Subscription | undefined;
  constructor(
    public router: Router,
      private authenticationService: LoginService,private authService : AuthService
  ) {
      this.router.errorHandler = (error: any) => {
      this.router.navigate(['/login']); // or redirect to default route
  }
 
      this.authenticationService.currentUser.subscribe(x => this.currentUser = x);
  }
  @HostListener('document:keyup', ['$event']) 
  @HostListener('document:click', ['$event'])
  @HostListener('document:wheel', ['$event'])
  @HostListener('document:mouseover', ['$event']) 
  resetTimer() {
    const currentUser = this.authenticationService.currentUserValue;
    if(currentUser != null){
    this.authService.notifyUserAction();
  }
  }
}