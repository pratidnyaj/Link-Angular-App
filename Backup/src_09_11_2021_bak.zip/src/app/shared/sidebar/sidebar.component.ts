import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subject, Subscription } from 'rxjs';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit,OnDestroy {

  unsubscribe$: Subject<void> = new Subject();
  timerSubscription: Subscription | undefined;
  constructor() { }
  ngOnInit(): void {
  }
  logout(){
    window.location.reload();
    sessionStorage.clear();
  }
  ngOnDestroy() {
    this.timerSubscription?.unsubscribe()
  }
}
