import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-side-conversation',
  templateUrl: './side-conversation.component.html',
  styleUrls: ['./side-conversation.component.scss']
})
export class SideConversationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
