import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sum-call-whatsapp-info',
  templateUrl: './sum-call-whatsapp-info.component.html',
  styleUrls: ['./sum-call-whatsapp-info.component.scss']
})
export class SumCallWhatsappInfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
