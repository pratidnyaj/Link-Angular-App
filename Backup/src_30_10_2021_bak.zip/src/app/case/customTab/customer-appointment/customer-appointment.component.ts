import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-appointment',
  templateUrl: './customer-appointment.component.html',
  styleUrls: ['./customer-appointment.component.scss']
})
export class CustomerAppointmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
