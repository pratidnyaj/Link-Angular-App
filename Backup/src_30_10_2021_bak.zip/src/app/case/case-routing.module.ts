import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CaseHomeComponent } from './case-home/case-home.component';

const routes: Routes = [
  {
    path: 'case',
    component: CaseHomeComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class caseRoutingModule { }
