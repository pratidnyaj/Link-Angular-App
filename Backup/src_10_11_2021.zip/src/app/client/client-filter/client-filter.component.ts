import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

@Component({
  selector: 'app-client-filter',
  templateUrl: './client-filter.component.html',
  styleUrls: ['./client-filter.component.scss']
})
export class ClientFilterComponent implements OnInit {
  @Input() collaborateFilter: string | undefined;
  @Output() clientFilterEvent = new EventEmitter();

  searchShow: boolean = false;
  selectedClientOption: any;
  arrClientOption = new Array();

  constructor() { }
  
  ngOnInit(): void {
    this.setClientOption();
    this.goToCaseList(this.selectedClientOption);
  }

  setCasesOption() {
    throw new Error('Method not implemented.');
  }

  toggleSearch() {
    this.searchShow = !this.searchShow;

  }
  
  goToCaseList(selectedClientOptionValue: any) {
    //We pass the data from child (case-filter) to parent (case-list)
    this.selectedClientOption = selectedClientOptionValue;
    //this.emitCaseFilterChanges();
  }
  emitCaseFilterChanges() {
    throw new Error('Method not implemented.');
  }
  setClientOption() {
    this.arrClientOption = [
      { "key": "Agent", "value": "Agent" },
      { "key": "Customer", "value": "Customer" },
      { "key": "Teams", "value": "Teams" },
      { "key": "Agent", "value": "Agent" },
      { "key": "Customer", "value": "Customer" },
      { "key": "Teams", "value": "Teams" },

    ]
  }
}
