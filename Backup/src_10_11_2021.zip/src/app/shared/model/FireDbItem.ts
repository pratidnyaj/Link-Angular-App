export default class FireDbItem {
  key: string = "";
  action: string = "";
  message: any = {};
  caseId: string = "";
}