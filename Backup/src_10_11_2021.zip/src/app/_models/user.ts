export class User {

    token?: string;
}