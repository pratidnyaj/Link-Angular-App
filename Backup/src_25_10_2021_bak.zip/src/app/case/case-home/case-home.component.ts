import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-case-home',
  templateUrl: './case-home.component.html',
  styleUrls: ['./case-home.component.scss']
})
export class CaseHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    
  }

}