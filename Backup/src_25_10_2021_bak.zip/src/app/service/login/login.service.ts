import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { AppService } from 'src/app/app.service';
import { LoginRQ, RoleRQ } from './loginDataModel';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  private baseUrl: string;

  constructor(private httpClient: HttpClient, private appService: AppService) {
    this.baseUrl = appService.getBaseUrl();
  }

  authenticateLogin(loginRq: LoginRQ) {
    const url = `${this.baseUrl}/loginApi`;
    return this.httpClient.post<any>(url, loginRq);
  }


  public GetRolePrivileges(RoleRQ:RoleRQ):Observable<any>{
    console.log(RoleRQ);
      const url = `${this.baseUrl}/GetRolePrivileges`;
      return this.httpClient.post<any>(url, RoleRQ);
  }

}