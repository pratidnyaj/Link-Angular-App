import { HttpClient } from '@angular/common/http';
import { Injectable,EventEmitter, Output, } from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { AppService } from '../app.service';

@Injectable({
  providedIn: 'root'
})
export class CaseService {

  private baseUrl: string;

  constructor(private httpclient: HttpClient, private appService: AppService) {
    this.baseUrl = appService.getBaseUrl();
  }


  @Output()  loadCaselistpage: EventEmitter<Object> = new EventEmitter()
  @Output()  loadcaseListFilter:EventEmitter<Object> = new EventEmitter()
  @Output()  selectCaseFilterName : EventEmitter<Object> = new EventEmitter();
  @Output()   popupModalActive : EventEmitter<Object> = new EventEmitter();
  @Output() ContactPopupModalActive : EventEmitter<Object> = new EventEmitter();
  @Output() modalInactive : EventEmitter<Object> = new EventEmitter();
  //#region Subscriptions

  //This Subject Observer will listen inside case-list component.
  private _caseIdSource = new BehaviorSubject('');
  _syncCaseId = this._caseIdSource.asObservable();

  syncCaseId(message: string) {
    this._caseIdSource.next(message)
  }

  //This Subject is used to emit changes on case-list selection.
  //Subscribers :: case-info, case-interaction-list 
  private _caseSubjectSource = new Subject<any>();
  observeCaseData(): Observable<any> {
    return this._caseSubjectSource.asObservable();
  }
  emitCaseData(oCase: any) {
    this._caseSubjectSource.next(oCase);
  }
    //This Subject is used to emit changes on dropdown 
  //Subscribers :: case-list-interaction 
  private _disp_subdisp_subsubdisp_source = new Subject<any>();
  observeDrpData(): Observable<any> {
    return this._disp_subdisp_subsubdisp_source.asObservable();
  }
  emitDrowpdownSelectedData(oDrp: any) {
    this._disp_subdisp_subsubdisp_source.next(oDrp);
  }

  //#endregion

    public assignCaseToMe(strCaseId: string, strUserId: string): Observable<any> {
    const url = `${this.baseUrl}/AssignCaseToSelf?Action=PickUpCase&caseid=${strCaseId}&UserID=${strUserId}`;
    return this.httpclient.get(url);
    }
  
     public assignCase(strCaseId: string, strUserId: string,strTeamId:string,strAgentId:string): Observable<any> {
        const url = `${this.baseUrl}/AssignCaseToAgent?Action=AssignCase&caseid=${strCaseId}&UserID=${strUserId}&teamId=${strTeamId}&agentId=${strAgentId}`;
        return this.httpclient.get(url);
      }

      public getPastCaseList(): Observable<any> {
        return this.httpclient.get('./assets/json/past-case.json');
      }
      public mergecase(mergecaseId: string,parentcaseId:string,userId:string): Observable<any> {
        const url = `${this.baseUrl}/Merge?Action=Merge&mergecaseid=${mergecaseId}&parentcaseid=${parentcaseId}&UserID=${userId}`;
        return this.httpclient.get<any>(url);
      }
    
      //Code reusablity
      postData(urlPrefix: string, query:any): Observable<any> {
        const url = `${this.baseUrl}/${urlPrefix}`;
        return this.httpclient.post<any>(url, query)
        }





  // public markCaseAsBlock(blockRq: any): Observable<any> {
  //   const url = `${this.baseUrl}/MarkBlock`;
  //   return this.httpclient.post<any>(url, blockRq);
  // }

  // public markCaseAsSpam(spamRq: any): Observable<any> {
  //   const url = `${this.baseUrl}/MarkSpam`;
  //   return this.httpclient.post<any>(url, spamRq);
  // }

  // public CaseClose(closeRq: any): Observable<any> {
  //   const url = `${this.baseUrl}/closeCase`;
  //   return this.httpclient.post<any>(url, closeRq);
  // }
 

  // public createInteraction(interactionRq: any): Observable<any> {
  //   const url = `${this.baseUrl}/sendMail`;
  //   return this.httpclient.post<any>(url, interactionRq);
  // }

  // public getMailBoxInfo(mailBoxRq: any): Observable<any> {
  //   const url = `${this.baseUrl}/mailBox`;
  //   return this.httpclient.post<any>(url, mailBoxRq);
  // }

  // public getCaseInteractionHistory(caseInteractionHistoryRq: any): Observable<any> {
  //   const url = `${this.baseUrl}/caseHistory`;
  //   return this.httpclient.post<any>(url, caseInteractionHistoryRq);
  //   //return this.httpclient.get('./assets/json/interaction-history-list.json');
  // }

  // public getCaseList(caseListRq: any): Observable<any> {
  //   const url = `${this.baseUrl}/fetchcaseApi`;
  //   //return this.httpclient.get('./assets/json/cases-list.json');
  //   return this.httpclient.post<any>(url, caseListRq);
  // }

//   public getCaseInfo(caseInfoRq: any): Observable<any> {
//     const url = `${this.baseUrl}/caseinfoApi`;
// console.log(`${this.baseUrl}/caseinfoApi`,caseInfoRq)

//     //return this.httpclient.get('./assets/json/case-details.json');
//     return this.httpclient.post<any>(url, caseInfoRq);
//   }

  // public getContactInfo(contactInfoRq: any): Observable<any> {
  //   const url = `${this.baseUrl}/contactinfoApi`;
  //   return this.httpclient.post<any>(url, contactInfoRq);
  // }

 
  // public getDisposition(dispositionRq: any): Observable<any> {
  //   const url = `${this.baseUrl}/Getdisposition`;
  //   return this.httpclient.post<any>(url, dispositionRq);
  // }


  // public getSubdisposition(subdispositionRq: any): Observable<any> {
  //   const url = `${this.baseUrl}/Getsubdisposition`;
  //   return this.httpclient.post<any>(url, subdispositionRq);
  // }
  
  // public getSubsubdisposition(subsubdispositionRq: any): Observable<any> {
  //   const url = `${this.baseUrl}/Getsubsubdisposition`;
  //   return this.httpclient.post<any>(url, subsubdispositionRq);
  // }
  

  caselistReload() {
    this.loadCaselistpage.emit()
  }
  modalcloseInactive(){
    console.log('hdhjhjhd');
    
    this.modalInactive.emit()
  }
  caseListFilterReload( value : any){
    this.loadcaseListFilter.emit(value)
  }
  selectFilterDefault(value : any){
    this.selectCaseFilterName.emit(value)
  }
  //Case and contact PopUp Modal
  casepopupModal(value : any){
    if( 'casemodalOne' === value){
    this.popupModalActive.emit(value)
  }
  else if('contactModal' === value){
    this.ContactPopupModalActive.emit(value)
  }
  }
}